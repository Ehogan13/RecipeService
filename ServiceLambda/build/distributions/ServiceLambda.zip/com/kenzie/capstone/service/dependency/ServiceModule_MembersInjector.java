package com.kenzie.capstone.service.dependency;

import com.kenzie.capstone.service.LambdaRecipeService;
import com.kenzie.capstone.service.LambdaService;
import com.kenzie.capstone.service.dao.ExampleDao;
import com.kenzie.capstone.service.dao.RecipeDao;
import dagger.MembersInjector;
import javax.annotation.processing.Generated;
import javax.inject.Provider;

@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes"
})
public final class ServiceModule_MembersInjector implements MembersInjector<ServiceModule> {
  private final Provider<ExampleDao> exampleDaoProvider;

  private final Provider<RecipeDao> recipeDaoProvider;

  public ServiceModule_MembersInjector(Provider<ExampleDao> exampleDaoProvider,
      Provider<RecipeDao> recipeDaoProvider) {
    this.exampleDaoProvider = exampleDaoProvider;
    this.recipeDaoProvider = recipeDaoProvider;
  }

  public static MembersInjector<ServiceModule> create(Provider<ExampleDao> exampleDaoProvider,
      Provider<RecipeDao> recipeDaoProvider) {
    return new ServiceModule_MembersInjector(exampleDaoProvider, recipeDaoProvider);
  }

  @Override
  public void injectMembers(ServiceModule instance) {
    injectProvideLambdaService(instance, exampleDaoProvider.get());
    injectProvideLambdaRecipeService(instance, recipeDaoProvider.get());
  }

  public static LambdaService injectProvideLambdaService(ServiceModule instance,
      ExampleDao exampleDao) {
    return instance.provideLambdaService(exampleDao);
  }

  public static LambdaRecipeService injectProvideLambdaRecipeService(ServiceModule instance,
      RecipeDao recipeDao) {
    return instance.provideLambdaRecipeService(recipeDao);
  }
}
